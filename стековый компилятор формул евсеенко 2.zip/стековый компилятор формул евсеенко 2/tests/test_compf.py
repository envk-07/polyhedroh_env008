from compf import Compf
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def test_1():
    c = Compf()
    assert c.compile("I + I") == "0o1 0o1 +"


def test_2():
    c = Compf()
    assert c.compile("I + III") == "0o1 0o3 +"


def test_3():
    c = Compf()
    assert c.compile("I - II + III") == "0o1 0o2 - 0o3 +"


def test_4():
    c = Compf()
    assert c.compile("I + II * III") == "0o1 0o2 0o3 * +"


def test_5():
    c = Compf()
    assert c.compile("( I - II ) * III") == "0o1 0o2 - 0o3 *"


def test_6():
    c = Compf()
    assert c.compile("( I - II ) * III / IV") == "0o1 0o2 - 0o3 * 0o4 /"


def test_7():
    c = Compf()
    assert c.compile("MCM") == "0o3554"


def test_8():
    c = Compf()
    assert c.compile("( X - V ) * II / IV") == "0o12 0o5 - 0o2 * 0o4 /"
