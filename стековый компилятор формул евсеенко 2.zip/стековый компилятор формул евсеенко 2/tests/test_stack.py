# tests/test_compf.py
import sys
import os
import unittest

# Добавляем родительскую директорию в путь поиска модулей
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))



from pytest import raises
from stack import Stack


class TestStack:

    # Инициализация (выполняется для каждого из тестов класса)
    def setup_method(self):
        self.s = Stack()

    # Сразу после создания стек пуст
    def test_simple1(self):
        assert self.s.array == []

    # Простые действия со стеком
    def test_simple2(self):
        self.s.push(1)
        assert self.s.array == [1]
        a = self.s.pop()
        assert a == 1

    # У пустого стека нет верхнего элемента
    def test_raises(self):
        with raises(Exception):
            self.s.top()
