#!/usr/bin/env python3

import re
from stack import Stack


class Compf:
    """
    Стековый компилятор формул преобразует правильные
    арифметические формулы (цепочки языка, задаваемого
    грамматикой G0) в программы для стекового калькулятора
    (цепочки языка, определяемого грамматикой Gs):

    G0:
        F  ->  T  |  F+T  |  F-T
        T  ->  M  |  T*M  |  T/M
        M  -> (F) |   V
        V  ->  a  |   b   |   c   |  ...  |    z

    Gs:
        e  ->  e e + | e e - | e e * | e e / |
                     | a | b | ... | z
    В качестве операндов в формулах допустимы только
    однобуквенные имена переменных [a-z]
    """

    SYMBOLS = re.compile("[IVXLCDM]")

    def __init__(self):
        # Создание стека отложенных операций
        self.s = Stack()
        # Создание списка с результатом компиляции
        self.data = []

    def compile(self, str):
        self.data.clear()
        self.s = Stack()  # сброс стека
        # Разбиваем формулу на ЧАСТИ по пробелам и добавляем скобки
        parts = ["("] + str.split() + [")"]
        for part in parts:
            self.process_part(part)
        return " ".join(self.data)

    # Обработка частей формулы
    def process_part(self, part):
        if part == "(":
            self.s.push(part)
        elif part == ")":
            self.process_suspended_operators(part)
            self.s.pop()
        elif part in "+-*/":
            self.process_suspended_operators(part)
            self.s.push(part)
        else:
            # Значит число
            self.data.append(self.v_norm(part))

    @staticmethod
    def v_norm(n):
        ciferki = {
            'I': 1,
            'V': 5,
            'X': 10,
            'L': 50,
            'C': 100,
            'D': 500,
            'M': 1000
        }

        itog = 0
        pred = 0
        # идём справа налево
        for i in range(len(n) - 1, -1, -1):
            char = n[i]
            now = ciferki[char]
            if now < pred:
                itog -= now
            else:
                itog += now
                pred = now

        return oct(itog)

    # Обработка отложенных операций

    def process_suspended_operators(self, c):
        while self.is_precedes(self.s.top(), c):
            self.process_oper(self.s.pop())

    # Обработка имени переменной
    def process_value(self, c):
        self.data.append(self.v_norm(c))

    # Обработка символа операции
    def process_oper(self, c):
        self.data.append(c)

    # Проверка допустимости символа
    @classmethod
    def check_symbol(self, c):
        if not self.SYMBOLS.match(c):
            raise Exception(f"Недопустимый символ '{c}'")

    # Определение приоритета операции
    @staticmethod
    def priority(c):
        if c == "+":
            return 1
        if c == "-":
            return 2
        else:
            return 3

    # Определение отношения предшествования
    @staticmethod
    def is_precedes(a, b):
        if a == "(":
            return False
        elif b == ")":
            return True
        else:
            return Compf.priority(a) >= Compf.priority(b)


if __name__ == "__main__":
    c = Compf()
    while True:
        str = input("Арифметическая  формула: ")
        print(f"Результат её компиляции: {c.compile(str)}")
        print()
